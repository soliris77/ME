#!/bin/bash
# Retire complètement le journal des news (Alpha Vantage) du projet.
# Garde intactes les prédictions IA sur les bougies (aucun rapport avec ça).
set -e

echo "Suppression des fichiers du journal des news..."
rm -f artifacts/api-server/src/lib/alphaVantage.ts
rm -f artifacts/api-server/src/routes/news.ts
rm -f artifacts/wealthsimple-tracker/src/pages/MarketNewsJournal.tsx

echo "Remplacement des fichiers modifiés par leurs versions sans le journal..."
cp -f "$(dirname "$0")/artifacts/api-server/src/routes/index.ts" artifacts/api-server/src/routes/index.ts
cp -f "$(dirname "$0")/artifacts/wealthsimple-tracker/src/App.tsx" artifacts/wealthsimple-tracker/src/App.tsx
cp -f "$(dirname "$0")/lib/api-client-react/src/generated/api.ts" lib/api-client-react/src/generated/api.ts
cp -f "$(dirname "$0")/lib/api-client-react/src/generated/api.schemas.ts" lib/api-client-react/src/generated/api.schemas.ts
cp -f "$(dirname "$0")/lib/api-spec/openapi.yaml" lib/api-spec/openapi.yaml

echo "Terminé. Le journal des news (Alpha Vantage) a été retiré."
echo "Les prédictions IA sur les bougies (TechnicalAnalysis.tsx) restent en place."
