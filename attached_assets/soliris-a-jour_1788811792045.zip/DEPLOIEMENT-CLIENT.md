# Déployer une instance Soliris pour un client

> Route A : chaque client reçoit son propre déploiement, sa propre base, son
> propre mot de passe. Le code est identique d'une instance à l'autre — seule
> la configuration change. Aucune donnée n'est partagée entre clients, par
> construction : c'est ce qui rend cette route sûre malgré l'application
> mono-utilisateur.
>
> Compter environ 30 minutes pour la première, 10 minutes ensuite.

---

## Avant de commencer

Une chose à savoir avant de vendre : **cette application passe de vrais ordres
de bourse.** Une instance mal configurée ne produit pas un affichage bancal,
elle peut trader. Les étapes 5 et 8 ne sont pas optionnelles.

Il vous faut, par client :

- une base PostgreSQL vide (jamais réutiliser celle d'un autre client) ;
- un hébergement pour l'application (Replit, un VPS, un conteneur) ;
- la clé API Whop de **votre** compte vendeur — la même pour toutes les
  instances, c'est vous qui encaissez ;
- les identifiants de courtage **du client**, que lui seul saisira.

---

## 1. Cloner et installer

```bash
git clone <votre-dépôt> soliris-<nom-du-client>
cd soliris-<nom-du-client>
pnpm install
```

Rien de spécifique au client à ce stade.

---

## 2. Variables d'environnement

Créer un `.env` à la racine. Les valeurs ci-dessous sont un exemple à adapter,
pas des valeurs à recopier.

### Indispensables

```
DATABASE_URL=postgresql://…            # base VIDE, dédiée à ce client
SESSION_SECRET=<64 caractères aléatoires, uniques par instance>
```

`SESSION_SECRET` doit être **différent pour chaque client**. Un secret partagé
signifierait qu'un cookie de session valide sur une instance l'est sur les
autres.

### Abonnement (Whop)

```
WHOP_API_KEY=<votre clé vendeur>
WHOP_PLAN_ID=plan_…
WHOP_PRODUCT_ID=prod_…
PREMIUM_ENFORCED=true
```

`WHOP_API_KEY` est nouveau : sans lui, la vérification d'abonnement ne
fonctionne **que** sur Replit, via le connecteur. Hors Replit, son absence fait
échouer chaque vérification — et comme un échec laisse volontairement l'accès
ouvert (pour ne jamais bloquer un abonné sur une panne), le mur de paiement ne
fermerait jamais rien. Le symptôme est l'absence de symptôme : à vérifier à
l'étape 7.

`PREMIUM_ENFORCED=true` active réellement la fermeture des routes premium
(auto-trader, copy trading). Sans lui, le middleware se contente de journaliser
ce qu'il aurait refusé.

### Garde-fous de risque

```
MAX_ORDER_VALUE=5000
MAX_PORTFOLIO_EXPOSURE=25000
```

Valeurs de départ seulement : le client les ajuste ensuite depuis
*Paramètres*. Les poser bas au premier démarrage est la précaution qui coûte
le moins cher.

### Optionnelles

```
TWILIO_ACCOUNT_SID=…      # SMS ; sans lui, notifications par email uniquement
TWILIO_AUTH_TOKEN=…
TWILIO_FROM_NUMBER=…
```

SnapTrade et les clés Web Push ne se mettent pas ici : le client saisit
SnapTrade depuis l'écran *Courtier*, et les clés VAPID sont générées puis
persistées au premier démarrage.

---

## 3. Migrations

```bash
node scripts/apply-migrations.mjs
```

Les migrations sont idempotentes — les rejouer ne casse rien. La migration
`0010_subscription.sql` crée la table d'abonnement et y insère la ligne
`owner` ; c'est elle qui rend l'instance vendable.

---

## 4. Premier démarrage et mot de passe

```bash
pnpm build
pnpm start
```

Ouvrir l'instance : aucun mot de passe n'existe encore, l'application redirige
vers `/setup`. **C'est le client qui saisit ce mot de passe, pas vous.** Le
hash est stocké en base ; vous ne devez pas le connaître.

Si vous devez préparer l'instance avant de la livrer, utilisez un mot de passe
temporaire et demandez au client de le changer depuis *Paramètres → Sécurité*
à la première connexion.

---

## 5. Vérifier que l'instance est bien isolée

Trois contrôles, dans cet ordre. Ne pas livrer si l'un échoue.

1. **Base dédiée.** `SELECT count(*) FROM orders;` doit renvoyer `0` sur une
   instance neuve. Un chiffre non nul signifie que vous avez pointé la base
   d'un autre client.
2. **Session non partagée.** Se connecter sur l'instance A, puis ouvrir
   l'instance B dans le même navigateur : B doit demander le mot de passe.
   Si elle ne le demande pas, `SESSION_SECRET` est partagé.
3. **Courtier vide.** L'écran *Courtier* doit afficher « aucune connexion ».

---

## 6. Configurer Whop pour ce client

Dans votre tableau de bord Whop, l'URL de retour après paiement doit pointer
vers **cette instance** :

```
https://<domaine-du-client>/pricing?success=true
```

Une URL de retour pointant vers une autre instance renverrait le client sur le
tableau de bord de quelqu'un d'autre.

---

## 7. Vérifier que l'abonnement fonctionne vraiment

C'est le contrôle qu'on oublie, parce que tout *a l'air* de marcher sans lui.

1. Ouvrir `/tarifs` **sans être connecté** : le prix doit s'afficher. S'il
   reste sur la valeur de repli, `WHOP_API_KEY` est absente ou invalide.
2. Aller dans *Paramètres → Abonnement* et cliquer **Actualiser**. La ligne
   « Vérifié le … » doit se mettre à jour. Si un message d'erreur de
   synchronisation apparaît, corriger avant de livrer.
3. Avec `PREMIUM_ENFORCED=true` et **aucun** abonnement actif, ouvrir
   *Auto-Trader* : le mur de paiement doit apparaître. S'il n'apparaît pas,
   la vérification échoue en silence — revoir le point 1.

Le point 3 est le seul qui prouve que le mur existe. Les deux autres prouvent
seulement qu'il pourrait exister.

---

## 8. Avant de laisser le client trader

- Le kill-switch est-il accessible et compris du client ?
- `MAX_ORDER_VALUE` correspond-il à ce qu'il est prêt à risquer sur un ordre ?
- Le mode est-il sur **paper** au départ ? Ne passer en **live** que quand le
  client le demande explicitement, après avoir vu passer des ordres simulés.

---

## Fiche par client

À remplir et conserver — c'est ce qui vous évitera de confondre deux instances
dans six mois.

| Champ | Valeur |
|---|---|
| Client | |
| Domaine | |
| Base de données | |
| Date de mise en service | |
| Mode au départ | paper / live |
| `PREMIUM_ENFORCED` | |
| Mot de passe défini par | le client / temporaire à changer |

---

## Mettre à jour toutes les instances

C'est le coût réel de la route A, et il croît avec le nombre de clients.

```bash
git pull && pnpm install && node scripts/apply-migrations.mjs && pnpm build
# redémarrer le service
```

Tant que vous êtes à trois ou cinq clients, c'est supportable. Au-delà, c'est
le signal qu'il est temps d'attaquer le passage multi-comptes — le moment où
déployer devient une corvée est exactement celui où la route B se rentabilise.
