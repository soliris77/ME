import { db, alertsTable, notificationsTable } from "@workspace/db";
import { eq, and, lt, isNotNull, sql, inArray } from "drizzle-orm";
import { getQuotes, yahooFinance } from "../lib/yahoo";
import { sendEmail, alertEmailHtml, patternAlertEmailHtml, signalAlertEmailHtml } from "../lib/emailClient";
import { computeIndicators, analyzeTradingSignals } from "../lib/signals";
import { sendSms } from "../lib/smsClient";
import { resolveDestinations } from "../lib/notificationPrefs";
import { detectCandlePatterns, type OHLCPoint, type CandlePattern } from "../lib/patternDetect";
import { logger } from "../lib/logger";
import { sendPushToAll } from "../lib/webPush";

const DEFAULT_INTERVAL_MS = 90_000; // 90s — comfortably under Yahoo's informal rate limits
const SIGNAL_ALERT_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4h entre deux notifications pour une même alerte signal

// --- Rétention de l'historique des notifications ---
// Les alertes de pattern sont récurrentes (re-déclenchées toutes les 4 h), donc
// la table `notifications` grossirait indéfiniment sans purge. Politique :
//   1. Les entrées LUES de plus de NOTIFICATION_RETENTION_DAYS jours sont supprimées.
//   2. Au-delà de NOTIFICATION_MAX_ROWS entrées au total, les plus anciennes
//      entrées LUES sont supprimées (les non-lues ne sont jamais purgées, pour
//      ne pas faire disparaître une notification jamais consultée).
// La purge tourne au plus une fois par NOTIFICATION_PURGE_INTERVAL_MS, greffée
// sur le cycle du worker d'alertes.
const NOTIFICATION_RETENTION_DAYS = 90;
const NOTIFICATION_MAX_ROWS = 1000;
const NOTIFICATION_PURGE_INTERVAL_MS = 24 * 60 * 60 * 1000; // 1×/jour suffit

let lastNotificationPurgeAt = 0;

/**
 * Purge l'historique des notifications selon la politique de rétention
 * ci-dessus. N'échoue jamais le cycle d'alertes : erreurs avalées et loguées.
 * Exportée pour les tests.
 */
export async function purgeOldNotifications(): Promise<void> {
  try {
    const cutoff = new Date(Date.now() - NOTIFICATION_RETENTION_DAYS * 24 * 60 * 60 * 1000);

    // 1. Entrées lues trop vieilles
    const oldDeleted = await db
      .delete(notificationsTable)
      .where(and(isNotNull(notificationsTable.readAt), lt(notificationsTable.sentAt, cutoff)))
      .returning({ id: notificationsTable.id });

    // 2. Plafond global : si la table dépasse NOTIFICATION_MAX_ROWS, supprimer
    // les plus anciennes entrées LUES en excès.
    let capDeleted = 0;
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(notificationsTable);
    if (count > NOTIFICATION_MAX_ROWS) {
      const excess = count - NOTIFICATION_MAX_ROWS;
      const victims = await db
        .select({ id: notificationsTable.id })
        .from(notificationsTable)
        .where(isNotNull(notificationsTable.readAt))
        .orderBy(notificationsTable.sentAt)
        .limit(excess);
      if (victims.length > 0) {
        const deleted = await db
          .delete(notificationsTable)
          .where(inArray(notificationsTable.id, victims.map((v) => v.id)))
          .returning({ id: notificationsTable.id });
        capDeleted = deleted.length;
      }
    }

    if (oldDeleted.length > 0 || capDeleted > 0) {
      logger.info(
        { byAge: oldDeleted.length, byCap: capDeleted, retentionDays: NOTIFICATION_RETENTION_DAYS, maxRows: NOTIFICATION_MAX_ROWS },
        "Purged old notification history entries",
      );
    }
  } catch (err) {
    logger.error({ err }, "Failed to purge notification history");
  }
}

/** Lance la purge si la dernière remonte à plus de NOTIFICATION_PURGE_INTERVAL_MS. */
async function maybePurgeNotifications(): Promise<void> {
  if (Date.now() - lastNotificationPurgeAt < NOTIFICATION_PURGE_INTERVAL_MS) return;
  lastNotificationPurgeAt = Date.now();
  await purgeOldNotifications();
}

function isTriggered(condition: string, target: number, current: number): boolean {
  if (condition === "above") return current >= target;
  if (condition === "below") return current <= target;
  return false;
}

const STRENGTH_RANK: Record<string, number> = { faible: 1, moyen: 2, fort: 3 };

/**
 * Journalise une notification envoyée dans la table `notifications` — c'est
 * ce qui alimente le centre de notifications in-app (historique + badge non
 * lu). Ne doit jamais faire échouer l'envoi lui-même : erreurs avalées et
 * loguées.
 */
async function logNotification(entry: {
  alertId: number;
  symbol: string;
  name: string | null;
  alertType: string;
  title: string;
  body: string;
  channels: string[];
}): Promise<void> {
  try {
    await db.insert(notificationsTable).values({
      alertId: entry.alertId,
      symbol: entry.symbol,
      name: entry.name,
      alertType: entry.alertType,
      title: entry.title,
      body: entry.body,
      channels: entry.channels.join(","),
    });
  } catch (err) {
    logger.error({ err, alertId: entry.alertId }, "Failed to log notification history entry");
  }
}

function sentChannels(dest: { email: string | null; phone: string | null; sendEmail: boolean; sendSms: boolean }): string[] {
  const channels = ["push"];
  if (dest.sendEmail && dest.email) channels.push("email");
  if (dest.sendSms && dest.phone) channels.push("sms");
  return channels;
}

/**
 * Résout les destinations effectives (email + téléphone) et les canaux à
 * utiliser pour un déclenchement d'alerte donné : la surcharge par-alerte
 * (notifyEmail/notifyPhone) a priorité sur les préférences globales, mais le
 * *canal* (email/sms/both/none) reste toujours celui configuré globalement
 * pour ce type d'événement (priceAlert ou patternAlert).
 */
async function resolveAlertDestination(
  alert: { notifyEmail: string | null; notifyPhone: string | null },
  eventType: "priceAlert" | "patternAlert" | "signalAlert",
): Promise<{ email: string | null; phone: string | null; sendEmail: boolean; sendSms: boolean }> {
  const globalPrefs = await resolveDestinations(eventType);
  return {
    email: alert.notifyEmail ?? globalPrefs.email,
    phone: alert.notifyPhone ?? globalPrefs.phone,
    sendEmail: globalPrefs.sendEmail,
    sendSms: globalPrefs.sendSms,
  };
}

/**
 * Cherche un pattern qui vient tout juste d'apparaître (sur les 2 dernières
 * bougies seulement — pas tout l'historique) et qui correspond aux critères
 * de l'alerte (signal haussier/baissier et force minimale).
 */
function findMatchingRecentPattern(
  patterns: CandlePattern[],
  totalCandles: number,
  wantedSignal: string | null,
  minStrength: string | null,
): CandlePattern | undefined {
  const recentCutoff = totalCandles - 2; // les patterns détectés sur les 2 dernières bougies seulement
  const minRank = minStrength ? STRENGTH_RANK[minStrength] ?? 1 : 1;

  return patterns
    .filter((p) => p.idx >= recentCutoff)
    .filter((p) => p.signal !== "neutre")
    .filter((p) => !wantedSignal || p.signal === wantedSignal)
    .filter((p) => (STRENGTH_RANK[p.strength] ?? 1) >= minRank)
    .sort((a, b) => (STRENGTH_RANK[b.strength] ?? 1) - (STRENGTH_RANK[a.strength] ?? 1))[0];
}

async function fetchRecentOHLC(symbol: string): Promise<OHLCPoint[]> {
  const period1 = new Date(Date.now() - 60 * 24 * 60 * 60 * 1000); // 60 jours — largement assez pour détecter un pattern récent
  const result = await yahooFinance.chart(symbol, { period1, interval: "1d" });
  return (result.quotes ?? []).map((p: { date: string | number | Date; open?: number; high?: number; low?: number; close?: number; volume?: number }) => ({
    date: new Date(p.date).toISOString(),
    open: p.open ?? null,
    high: p.high ?? null,
    low: p.low ?? null,
    close: p.close ?? 0,
    volume: p.volume ?? null,
  }));
}

/**
 * Checks all active alerts (prix ET pattern/signal) against les données
 * courantes, marque les alertes déclenchées comme inactives, et envoie une
 * notification (email et/ou SMS, selon les préférences) pour chacune. Safe to
 * call concurrently-adjacent runs won't double-fire because we flip `active`
 * to false in the same query that reads the trigger condition.
 */
export async function checkAlerts(): Promise<void> {
  await maybePurgeNotifications();

  const active = await db.select().from(alertsTable).where(eq(alertsTable.active, true));
  if (active.length === 0) return;

  const priceAlerts = active.filter((a) => a.alertType !== "pattern");
  const patternAlerts = active.filter((a) => a.alertType === "pattern");
  const signalAlerts = active.filter((a) => a.alertType === "signal");

  // --- 1. Alertes de prix (comportement historique) ---
  if (priceAlerts.length > 0) {
    const symbols = [...new Set(priceAlerts.map((a) => a.symbol))];
    try {
      const quotes = await getQuotes(symbols);
      const priceBySymbol = new Map(quotes.map((q) => [q.symbol, q.price]));

      for (const alert of priceAlerts) {
        const currentPrice = priceBySymbol.get(alert.symbol);
        if (currentPrice === undefined || !alert.condition || alert.targetPrice === null) continue;

        const target = parseFloat(alert.targetPrice);
        if (!isTriggered(alert.condition, target, currentPrice)) continue;

        try {
          await db.update(alertsTable).set({ active: false, triggeredAt: new Date() }).where(eq(alertsTable.id, alert.id));

          // Web Push — notifie tous les navigateurs abonnés, même fermés.
          // Tag identique à celui du SW/de la page pour dédupliquer.
          const conditionLabel = alert.condition === "above" ? "au-dessus" : "en dessous";
          await sendPushToAll({
            title: `🔔 Alerte ${alert.symbol}`,
            body: `${alert.symbol} est passé ${conditionLabel} de ${target.toFixed(2)} $ (prix actuel : ${currentPrice.toFixed(2)} $)`,
            tag: `soliris-alert-${alert.id}`,
            url: "/alerts",
          }).catch((err) => logger.error({ err, alertId: alert.id }, "Web Push failed for price alert"));

          const dest = await resolveAlertDestination(alert, "priceAlert");
          await logNotification({
            alertId: alert.id,
            symbol: alert.symbol,
            name: alert.name,
            alertType: "price",
            title: `🔔 Alerte ${alert.symbol}`,
            body: `${alert.symbol} est passé ${conditionLabel} de ${target.toFixed(2)} $ (prix actuel : ${currentPrice.toFixed(2)} $)`,
            channels: sentChannels(dest),
          });
          if (dest.sendEmail && dest.email) {
            await sendEmail({
              to: dest.email,
              subject: `🔔 ${alert.symbol} a atteint ${target.toFixed(2)} $`,
              html: alertEmailHtml({ symbol: alert.symbol, name: alert.name, condition: alert.condition, targetPrice: target, currentPrice }),
            });
          } else if (dest.sendEmail) {
            logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Price alert triggered but email channel enabled with no destination configured");
          }
          if (dest.sendSms && dest.phone) {
            const conditionText = alert.condition === "above" ? "est monté au-dessus de" : "est descendu en dessous de";
            await sendSms({
              to: dest.phone,
              body: `🔔 ${alert.name ?? alert.symbol} (${alert.symbol}) ${conditionText} ${target.toFixed(2)} $. Prix actuel : ${currentPrice.toFixed(2)} $.`,
            });
          } else if (dest.sendSms) {
            logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Price alert triggered but SMS channel enabled with no phone number configured");
          }
          logger.info({ alertId: alert.id, symbol: alert.symbol, target, currentPrice }, "Price alert triggered");
        } catch (err) {
          logger.error({ err, alertId: alert.id }, "Failed to process triggered price alert");
        }
      }
    } catch (err) {
      logger.error({ err }, "alertWorker: failed to fetch quotes, skipping price alerts this cycle");
    }
  }

  // --- 2. Alertes de pattern/signal (nouveau — gratuit, même détection que l'analyse technique) ---
  for (const alert of patternAlerts) {
    try {
      if (alert.triggeredAt && Date.now() - alert.triggeredAt.getTime() < SIGNAL_ALERT_COOLDOWN_MS) continue;

      const history = await fetchRecentOHLC(alert.symbol);
      if (history.length < 15) continue; // pas assez de données pour détecter quoi que ce soit de fiable

      const patterns = detectCandlePatterns(history);
      const match = findMatchingRecentPattern(patterns, history.length, alert.patternSignal, alert.minStrength);
      if (!match) continue;

      await db.update(alertsTable).set({ triggeredAt: new Date() }).where(eq(alertsTable.id, alert.id));

      await sendPushToAll({
        title: `📊 ${alert.symbol} — ${match.name}`,
        body: `Pattern ${match.name} détecté sur ${alert.symbol} (signal ${match.signal}, force ${match.strength})`,
        tag: `soliris-alert-${alert.id}-${Date.now()}`, // pattern = récurrent, pas de dédup par id seul
        url: "/alerts",
      }).catch((err) => logger.error({ err, alertId: alert.id }, "Web Push failed for pattern alert"));

      const dest = await resolveAlertDestination(alert, "patternAlert");
      await logNotification({
        alertId: alert.id,
        symbol: alert.symbol,
        name: alert.name,
        alertType: "pattern",
        title: `📊 ${alert.symbol} — ${match.name}`,
        body: `Pattern ${match.name} détecté sur ${alert.symbol} (signal ${match.signal}, force ${match.strength})`,
        channels: sentChannels(dest),
      });
      if (dest.sendEmail && dest.email) {
        await sendEmail({
          to: dest.email,
          subject: `📊 ${alert.symbol} — ${match.name} détecté (${match.signal})`,
          html: patternAlertEmailHtml({
            symbol: alert.symbol,
            name: alert.name,
            patternName: match.name,
            signal: match.signal,
            strength: match.strength,
            description: match.description,
            howToUse: match.howToUse,
          }),
        });
      } else if (dest.sendEmail) {
        logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Pattern alert triggered but email channel enabled with no destination configured");
      }
      if (dest.sendSms && dest.phone) {
        await sendSms({
          to: dest.phone,
          body: `📊 ${alert.name ?? alert.symbol} (${alert.symbol}) — pattern ${match.name} détecté (signal ${match.signal}, force ${match.strength}).`,
        });
      } else if (dest.sendSms) {
        logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Pattern alert triggered but SMS channel enabled with no phone number configured");
      }
      logger.info({ alertId: alert.id, symbol: alert.symbol, pattern: match.name, signal: match.signal }, "Pattern alert triggered");
    } catch (err) {
      logger.error({ err, alertId: alert.id, symbol: alert.symbol }, "Failed to process pattern alert");
    }
  }

  // --- 3. Alertes de signal technique composite (RSI+MACD+SMA+Bollinger) ---
  for (const alert of signalAlerts) {
    try {
      const history = await fetchRecentOHLC(alert.symbol);
      if (history.length < 55) continue; // sma50 a besoin d'assez d'historique

      const data = computeIndicators(history);
      const currentPrice = history[history.length - 1].close;
      const analysis = analyzeTradingSignals(data, currentPrice, history);
      if (analysis.overall === "NEUTRE") continue;

      const isBuySide = analysis.overall === "ACHAT" || analysis.overall === "FORT ACHAT";
      const directionMatches = !alert.patternSignal
        || (alert.patternSignal === "haussier" && isBuySide)
        || (alert.patternSignal === "baissier" && !isBuySide);
      const strengthMatches = alert.minStrength === "fort"
        ? (analysis.overall === "FORT ACHAT" || analysis.overall === "FORTE VENTE")
        : true; // "moyen" (défaut) : ACHAT/VENTE ou plus fort suffit

      if (!directionMatches || !strengthMatches) continue;

      await db.update(alertsTable).set({ active: false, triggeredAt: new Date() }).where(eq(alertsTable.id, alert.id));

      await sendPushToAll({
        title: `📈 ${alert.symbol} — signal ${analysis.overall}`,
        body: `Signal technique ${analysis.overall} sur ${alert.symbol} (score ${analysis.score})`,
        tag: `soliris-alert-${alert.id}`,
        url: "/alerts",
      }).catch((err) => logger.error({ err, alertId: alert.id }, "Web Push failed for signal alert"));

      const dest = await resolveAlertDestination(alert, "signalAlert");
      await logNotification({
        alertId: alert.id,
        symbol: alert.symbol,
        name: alert.name,
        alertType: "signal",
        title: `📈 ${alert.symbol} — signal ${analysis.overall}`,
        body: `Signal technique ${analysis.overall} sur ${alert.symbol} (score ${analysis.score})`,
        channels: sentChannels(dest),
      });
      const topSignals = analysis.signals.filter((s) => s.verdict !== "neutral").slice(0, 3).map((s) => `${s.name}: ${s.value}`);

      if (dest.sendEmail && dest.email) {
        await sendEmail({
          to: dest.email,
          subject: `📈 ${alert.symbol} — signal ${analysis.overall}`,
          html: signalAlertEmailHtml({ symbol: alert.symbol, name: alert.name, overall: analysis.overall, score: analysis.score, topSignals }),
        });
      } else if (dest.sendEmail) {
        logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Signal alert triggered but email channel enabled with no destination configured");
      }
      if (dest.sendSms && dest.phone) {
        await sendSms({
          to: dest.phone,
          body: `📈 ${alert.name ?? alert.symbol} (${alert.symbol}) — signal ${analysis.overall} (score ${analysis.score}). ${topSignals[0] ?? ""}`,
        });
      } else if (dest.sendSms) {
        logger.warn({ alertId: alert.id, symbol: alert.symbol }, "Signal alert triggered but SMS channel enabled with no phone number configured");
      }
      logger.info({ alertId: alert.id, symbol: alert.symbol, overall: analysis.overall, score: analysis.score }, "Signal alert triggered");
    } catch (err) {
      logger.error({ err, alertId: alert.id, symbol: alert.symbol }, "Failed to process signal alert");
    }
  }
}

let intervalHandle: ReturnType<typeof setInterval> | null = null;

export function startAlertWorker(intervalMs = DEFAULT_INTERVAL_MS): void {
  if (intervalHandle) return; // already running

  logger.info({ intervalMs }, "Starting alert worker");

  // Run once immediately, then on the interval. Errors are caught inside
  // checkAlerts already, but wrap again defensively so a bad cycle never
  // kills the interval.
  void checkAlerts().catch((err) => logger.error({ err }, "alertWorker: initial run failed"));

  intervalHandle = setInterval(() => {
    void checkAlerts().catch((err) => logger.error({ err }, "alertWorker: cycle failed"));
  }, intervalMs);
}

export function stopAlertWorker(): void {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}
