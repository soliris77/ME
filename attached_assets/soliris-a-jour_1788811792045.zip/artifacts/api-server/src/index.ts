import app from "./app";
import { logger } from "./lib/logger";
import { startAlertWorker } from "./workers/alertWorker";
import { startAutoTradeWorker } from "./workers/autoTradeWorker";
import { startDailySummaryWorker } from "./workers/dailySummaryWorker";
import { db, brokerConnectionsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { persistConsumerKeyIfNeeded, resolveCredentials } from "./lib/snaptrade";
import { persistExternalCredsIfNeeded } from "./lib/persistCreds";
import { sealExistingSecrets } from "./lib/sealExistingSecrets";
import { activeSignalEngine } from "./lib/signals";
import { isWhopConfigured } from "./whopClient";
import { isFounderConfigured, founderCodeTooShort } from "./lib/founder";

const port = Number(process.env["PORT"] ?? "8080");

/**
 * Vérifie au démarrage si les clés développeur SnapTrade sont présentes (DB ou env).
 * Ne tente jamais l'auto-setup — l'utilisateur clique "Initialiser" dans l'UI.
 * Sert uniquement à loguer l'état pour le diagnostic.
 */
async function checkBrokerCredentialsAtStartup() {
  try {
    const creds = await resolveCredentials();
    const hasDevCreds = !!(creds.clientId && creds.consumerKey);
    logger.info(
      { hasClientId: !!creds.clientId, hasConsumerKey: !!creds.consumerKey },
      hasDevCreds
        ? "broker: clés développeur SnapTrade présentes (DB ou env) — prêt"
        : "broker: clés développeur SnapTrade absentes — à configurer via /courtier"
    );

    if (hasDevCreds) {
      const rows = await db
        .select()
        .from(brokerConnectionsTable)
        .orderBy(desc(brokerConnectionsTable.id))
        .limit(1);
      if (rows.length > 0) {
        logger.info({ status: rows[0].status }, "broker: connexion existante trouvée en base");
      } else {
        logger.info("broker: aucune connexion courtier — l'utilisateur doit cliquer Initialiser dans /courtier");
      }
    }
  } catch (err) {
    logger.warn({ err }, "broker: erreur lors de la vérification des credentials au démarrage");
  }
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Quel scoreur pilote l'auto-trader — à voir d'un coup d'œil dans les logs.
  const engine = activeSignalEngine();
  logger.info(
    { signalEngine: engine },
    engine === "unified"
      ? "signaux : moteur unifié — l'auto-trader et les graphiques disent la même chose"
      : "signaux : ANCIEN moteur (SIGNAL_ENGINE=legacy) — l'auto-trader diverge des graphiques",
  );

  // ─── Abonnement : dire tout de suite si le mur de paiement est inopérant ──
  const premiumEnforced = process.env.PREMIUM_ENFORCED === "true";
  const whopReady = isWhopConfigured();
  if (premiumEnforced && !whopReady) {
    logger.error(
      "abonnement : PREMIUM_ENFORCED=true mais aucune clé Whop (WHOP_API_KEY ou " +
      "connecteur Replit). Chaque vérification échouera, et un échec laisse " +
      "volontairement l'accès ouvert : le mur de paiement ne fermera RIEN.",
    );
  } else if (!premiumEnforced) {
    logger.info(
      "abonnement : PREMIUM_ENFORCED non activé — les routes premium restent " +
      "ouvertes, les refus sont seulement journalisés.",
    );
  } else {
    logger.info("abonnement : mur de paiement actif, clé Whop présente.");
  }

  // Clé fondateur : on dit qu'elle existe, jamais ce qu'elle vaut.
  if (founderCodeTooShort()) {
    logger.warn(
      "fondateur : FOUNDER_CODE fait moins de 12 caractères et est ignoré. " +
      "Mets-y une chaîne longue et aléatoire, ou retire la ligne.",
    );
  } else if (isFounderConfigured()) {
    logger.info("fondateur : clé configurée — accès propriétaire disponible dans les réglages.");
  }

  const alertIntervalMs = Number(process.env.ALERT_CHECK_INTERVAL_MS ?? "90000");
  startAlertWorker(Number.isFinite(alertIntervalMs) && alertIntervalMs > 0 ? alertIntervalMs : undefined);
  startAutoTradeWorker();
  startDailySummaryWorker();

  // Persiste les credentials depuis env vars → DB si absents en base (premier démarrage)
  persistConsumerKeyIfNeeded().catch((err) =>
    logger.warn({ err }, "snaptrade: persistConsumerKeyIfNeeded a échoué au démarrage")
  );

  persistExternalCredsIfNeeded().catch((err) =>
    logger.warn({ err }, "persistExternalCredsIfNeeded a échoué au démarrage")
  );

  // Chiffre au repos les secrets courtier encore stockés en clair.
  sealExistingSecrets().catch((err) =>
    logger.warn({ err }, "sealExistingSecrets a échoué au démarrage")
  );

  checkBrokerCredentialsAtStartup().catch((err) =>
    logger.error({ err }, "broker: erreur dans checkBrokerCredentialsAtStartup")
  );
});
