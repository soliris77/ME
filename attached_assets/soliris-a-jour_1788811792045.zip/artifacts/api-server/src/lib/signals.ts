/**
 * Signaux de trading — point d'entrée unique du serveur.
 * ═════════════════════════════════════════════════════════════════════════
 * Jusqu'au 27 août 2026, ce fichier contenait un second scoreur, distinct de
 * celui qui alimente les graphiques. Les deux rendaient un verdict différent
 * dans 29 % des cas : l'utilisateur voyait une analyse à l'écran pendant que
 * le robot en exécutait une autre.
 *
 * Ce fichier est désormais un aiguillage. Le calcul vit dans
 * `@workspace/indicators`, partagé mot pour mot avec l'interface — une seule
 * implémentation, un seul verdict.
 *
 *   SIGNAL_ENGINE=unified  (défaut) — le moteur des graphiques
 *   SIGNAL_ENGINE=legacy            — l'ancien scoreur (signalsLegacy.ts)
 *
 * Le repli existe pour une seule raison : pouvoir revenir en arrière en
 * production sans redéployer, si le nouveau moteur se comporte autrement
 * qu'attendu. Ce n'est pas un choix à laisser ouvert indéfiniment.
 *
 * ── Sur le passage de `history` ──────────────────────────────────────────
 * Le moteur unifié accepte l'historique OHLC en troisième argument. Sans lui,
 * il fonctionne mais perd la pondération par régime de marché — c'est-à-dire
 * précisément ce qui le distingue de l'ancien. Tous les appelants du serveur
 * l'ont sous la main : ils le passent. L'argument reste optionnel pour ne
 * casser aucun appel existant.
 */
import {
  computeIndicators as computeUnified,
  analyzeTradingSignals as analyzeUnified,
} from "@workspace/indicators";
import {
  computeIndicators as computeLegacy,
  analyzeTradingSignals as analyzeLegacy,
} from "./signalsLegacy";
import type { OHLCPoint } from "./patternDetect";

// Les types sont identiques des deux côtés : on réexporte ceux du paquet
// partagé, qui font désormais autorité.
export type {
  IndicatorPoint,
  SignalStrength,
  TradingSignal,
} from "@workspace/indicators";

import type { IndicatorPoint, TradingSignal } from "@workspace/indicators";

export type SignalEngine = "unified" | "legacy";

/** Moteur actif, relu à chaque appel pour rester testable. */
export function activeSignalEngine(): SignalEngine {
  return process.env.SIGNAL_ENGINE === "legacy" ? "legacy" : "unified";
}

export function computeIndicators(history: OHLCPoint[]): IndicatorPoint[] {
  return activeSignalEngine() === "legacy"
    ? computeLegacy(history)
    : computeUnified(history);
}

/**
 * @param data          Indicateurs calculés par computeIndicators()
 * @param currentPrice  Prix courant
 * @param history       Historique OHLC brut — à passer systématiquement :
 *                      c'est lui qui active la détection de régime de marché.
 */
export function analyzeTradingSignals(
  data: IndicatorPoint[],
  currentPrice: number,
  history?: OHLCPoint[],
): TradingSignal {
  return activeSignalEngine() === "legacy"
    ? analyzeLegacy(data, currentPrice)
    : analyzeUnified(data, currentPrice, history);
}
