/**
 * Chiffrement des identifiants MetaTrader.
 *
 * L'implémentation vit désormais dans `lib/crypto.ts`, partagée avec les
 * secrets courtier SnapTrade. Ce fichier reste le point d'entrée historique
 * pour l'intégration MetaTrader — les imports existants continuent de marcher.
 */
export { encrypt, decrypt } from "../../crypto";
