/**
 * Parallax — décalage vertical léger lié au défilement.
 * ──────────────────────────────────────────────────────────────────────────
 * Réservé aux éléments DÉCORATIFS (halos, emblèmes, fonds). Ne jamais
 * l'appliquer à du texte lisible ni à des chiffres : le décalage nuit
 * à la lecture. `speed` positif = l'élément traîne derrière le scroll.
 */

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef, type ReactNode } from "react";

interface ParallaxProps {
  children: ReactNode;
  /** Amplitude en pixels sur toute la traversée de l'écran. 0.2 = discret. */
  speed?: number;
  className?: string;
}

export function Parallax({ children, speed = 0.2, className }: ParallaxProps) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const amplitude = 140 * speed;
  const y = useTransform(scrollYProgress, [0, 1], [amplitude, -amplitude]);

  if (reduced) {
    return (
      <div ref={ref} className={className}>
        {children}
      </div>
    );
  }

  return (
    <div ref={ref} className={className}>
      <motion.div style={{ y, willChange: "transform" }}>{children}</motion.div>
    </div>
  );
}
