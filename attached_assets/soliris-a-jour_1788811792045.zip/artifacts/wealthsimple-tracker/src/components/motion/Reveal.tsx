/**
 * Reveal — révélation d'un bloc à l'entrée dans le viewport.
 * ──────────────────────────────────────────────────────────────────────────
 * Primitive de base du langage visuel Soliris. Ne joue qu'une fois.
 * Si l'utilisateur a demandé moins d'animations, le contenu est rendu
 * immédiatement, sans wrapper animé.
 */

import { motion, useReducedMotion } from "framer-motion";
import type { ElementType, ReactNode } from "react";
import {
  DUR,
  REVEAL_VIEWPORT,
  revealVariants,
  type RevealDirection,
} from "@/lib/motion";

interface RevealProps {
  children: ReactNode;
  /** Direction d'arrivée. Par défaut : montée. */
  direction?: RevealDirection;
  /** Multiplicateur de distance (0.5 = plus discret, 2 = plus ample). */
  distance?: number;
  /** Retard avant démarrage, en secondes. */
  delay?: number;
  duration?: number;
  className?: string;
  /** Balise rendue (section, li, article…). */
  as?: ElementType;
}

export function Reveal({
  children,
  direction = "up",
  distance = 1,
  delay = 0,
  duration = DUR.slow,
  className,
  as = "div",
}: RevealProps) {
  const reduced = useReducedMotion();
  const Comp = motion[as as "div"] ?? motion.div;

  if (reduced) {
    const Static = as as ElementType;
    return <Static className={className}>{children}</Static>;
  }

  return (
    <Comp
      className={className}
      variants={revealVariants(direction, distance, duration)}
      initial="initial"
      whileInView="enter"
      viewport={REVEAL_VIEWPORT}
      transition={{ delay }}
    >
      {children}
    </Comp>
  );
}
