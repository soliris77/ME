/**
 * TiltCard — profondeur au déplacement de la souris.
 * ──────────────────────────────────────────────────────────────────────────
 * Bascule 3D très mesurée + reflet doré qui suit le curseur. Pensé pour les
 * cartes mises en avant (offre d'abonnement, position vedette), pas pour
 * l'ensemble d'un tableau : l'effet perd sa valeur s'il est partout.
 */

import {
  motion,
  useMotionTemplate,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from "framer-motion";
import type { PointerEvent, ReactNode } from "react";
import { TILT } from "@/lib/motion";

interface TiltCardProps {
  children: ReactNode;
  className?: string;
  /** Intensité relative de la bascule. 0 désactive la rotation. */
  intensity?: number;
  /** Reflet doré suivant le curseur. */
  glare?: boolean;
}

export function TiltCard({
  children,
  className,
  intensity = 1,
  glare = true,
}: TiltCardProps) {
  const reduced = useReducedMotion();

  // Position normalisée du curseur dans la carte, de -0.5 à 0.5.
  const px = useMotionValue(0);
  const py = useMotionValue(0);

  const rx = useSpring(
    useTransform(py, [-0.5, 0.5], [TILT.maxRotate * intensity, -TILT.maxRotate * intensity]),
    TILT.spring,
  );
  const ry = useSpring(
    useTransform(px, [-0.5, 0.5], [-TILT.maxRotate * intensity, TILT.maxRotate * intensity]),
    TILT.spring,
  );

  const glareX = useTransform(px, [-0.5, 0.5], ["0%", "100%"]);
  const glareY = useTransform(py, [-0.5, 0.5], ["0%", "100%"]);
  const glareBg = useMotionTemplate`radial-gradient(340px circle at ${glareX} ${glareY}, hsl(43 80% 78% / 0.16), transparent 62%)`;

  if (reduced) {
    return <div className={className}>{children}</div>;
  }

  function handleMove(e: PointerEvent<HTMLDivElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    px.set((e.clientX - r.left) / r.width - 0.5);
    py.set((e.clientY - r.top) / r.height - 0.5);
  }

  function handleLeave() {
    px.set(0);
    py.set(0);
  }

  return (
    <motion.div
      className={className}
      onPointerMove={handleMove}
      onPointerLeave={handleLeave}
      style={{
        rotateX: rx,
        rotateY: ry,
        transformPerspective: TILT.perspective,
        transformStyle: "preserve-3d",
        position: "relative",
        willChange: "transform",
      }}
      whileHover={{ scale: TILT.scale }}
      transition={{ type: "spring", ...TILT.spring }}
    >
      {children}
      {glare && (
        <motion.span
          aria-hidden
          style={{
            background: glareBg,
            position: "absolute",
            inset: 0,
            borderRadius: "inherit",
            pointerEvents: "none",
          }}
        />
      )}
    </motion.div>
  );
}
