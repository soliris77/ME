/**
 * PageTransition — enveloppe d'entrée/sortie pour toutes les pages.
 * ──────────────────────────────────────────────────────────────────────────
 * v2 : transition cinématique (montée + léger dézoom + net qui se fait).
 * L'API reste identique — les pages existantes n'ont rien à changer.
 *   variant="cinematic" (défaut) — pages principales
 *   variant="soft"                — panneaux, sous-vues, changements fréquents
 */

import { motion, useReducedMotion } from "framer-motion";
import { pageVariants, pageVariantsCinematic } from "@/lib/motion";
import type { ReactNode } from "react";

interface PageTransitionProps {
  children: ReactNode;
  className?: string;
  variant?: "cinematic" | "soft";
}

export function PageTransition({
  children,
  className = "",
  variant = "cinematic",
}: PageTransitionProps) {
  const reduced = useReducedMotion();

  if (reduced) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      initial="initial"
      animate="enter"
      exit="exit"
      variants={variant === "soft" ? pageVariants : pageVariantsCinematic}
      className={className}
    >
      {children}
    </motion.div>
  );
}
