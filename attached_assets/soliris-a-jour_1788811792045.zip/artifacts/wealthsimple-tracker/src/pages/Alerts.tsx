import {
  useGetAlerts,
  useCreateAlert,
  useDeleteAlert,
  getGetAlertsQueryKey,
  useGetNotifications,
  useMarkAllNotificationsRead,
  getGetNotificationsQueryKey,
  getGetNotificationsUnreadCountQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import { playSound } from "@/lib/sounds";
import { formatPrice } from "@/lib/format";
import { Bell, BellOff, Plus, Trash2, X, TrendingUp, TrendingDown, Sparkles, History, Mail, MessageSquare, Smartphone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Alert, NotificationEntry } from "@workspace/api-client-react";

function requestNotificationPermission() {
  if ("Notification" in window) {
    Notification.requestPermission();
  }
}

function sendNotification(title: string, body: string) {
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification(title, { body, icon: "/favicon.ico" });
  }
}

interface SymbolSuggestion {
  symbol: string;
  name: string;
  exchange: string;
  type: string;
}

function CreateAlertModal({ onClose }: { onClose: () => void }) {
  const [alertType, setAlertType] = useState<"price" | "pattern" | "signal">("price");
  const [symbol, setSymbol] = useState("");
  const [name, setName] = useState("");
  // Champs pour une alerte de prix
  const [condition, setCondition] = useState<"above" | "below">("above");
  const [price, setPrice] = useState("");
  // Champs pour une alerte de pattern/signal
  const [patternSignal, setPatternSignal] = useState<"haussier" | "baissier" | "">("");
  const [minStrength, setMinStrength] = useState<"faible" | "moyen" | "fort" | "">("moyen");

  // Autocomplete symbole
  const [suggestions, setSuggestions] = useState<SymbolSuggestion[]>([]);
  const [suggestionOpen, setSuggestionOpen] = useState(false);
  const [suggestionLoading, setSuggestionLoading] = useState(false);
  const symbolWrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (symbol.length < 1) { setSuggestions([]); setSuggestionOpen(false); return; }
    setSuggestionLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/symbols/search?q=${encodeURIComponent(symbol)}`);
        const data: SymbolSuggestion[] = await res.json();
        setSuggestions(data);
        setSuggestionOpen(data.length > 0);
      } catch { /* ignore */ } finally {
        setSuggestionLoading(false);
      }
    }, 200);
    return () => clearTimeout(t);
  }, [symbol]);

  // Ferme le dropdown si on clique en dehors
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (symbolWrapRef.current && !symbolWrapRef.current.contains(e.target as Node)) {
        setSuggestionOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const pickSuggestion = (s: SymbolSuggestion) => {
    setSymbol(s.symbol);
    if (!name) setName(s.name);
    setSuggestionOpen(false);
    setSuggestions([]);
  };

  const TYPE_LABEL: Record<string, string> = {
    EQUITY: "Action", ETF: "ETF", CRYPTOCURRENCY: "Crypto",
    INDEX: "Indice", MUTUALFUND: "Fonds", FUTURE: "Future",
  };

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const create = useCreateAlert({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAlertsQueryKey() });
        playSound("success");
        toast({ title: "Alerte créée avec succès" });
        onClose();
      },
      onError: () => { playSound("error"); toast({ title: "Erreur lors de la création", variant: "destructive" }); },
    },
  });

  const canSubmit =
    !!symbol &&
    (alertType === "price" ? !!price && !isNaN(parseFloat(price)) : true) &&
    !create.isPending;

  const handleCreate = () => {
    if (alertType === "price") {
      create.mutate({
        data: { symbol, name: name || undefined, alertType: "price", condition, targetPrice: parseFloat(price) },
      });
    } else if (alertType === "signal") {
      create.mutate({
        data: {
          symbol,
          name: name || undefined,
          alertType: "signal",
          patternSignal: patternSignal || undefined,
          minStrength: minStrength || undefined,
        },
      });
    } else {
      create.mutate({
        data: {
          symbol,
          name: name || undefined,
          alertType: "pattern",
          patternSignal: patternSignal || undefined,
          minStrength: minStrength || undefined,
        },
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-card border border-card-border rounded-xl p-6 w-full max-w-sm shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-bold">Nouvelle alerte</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          <button
            onClick={() => setAlertType("price")}
            className={`py-2 text-sm font-medium rounded-md border transition-colors flex items-center justify-center gap-1.5 ${
              alertType === "price" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
            }`}
          >
            <Bell className="w-3.5 h-3.5" /> Prix
          </button>
          <button
            onClick={() => setAlertType("pattern")}
            className={`py-2 text-sm font-medium rounded-md border transition-colors flex items-center justify-center gap-1.5 ${
              alertType === "pattern" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Pattern
          </button>
          <button
            onClick={() => setAlertType("signal")}
            className={`py-2 text-sm font-medium rounded-md border transition-colors flex items-center justify-center gap-1.5 ${
              alertType === "signal" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Signal
          </button>
        </div>

        <div className="space-y-3">
          <div ref={symbolWrapRef} className="relative">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Symbole</label>
            <div className="relative">
              <input
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring font-mono uppercase"
                placeholder="ex: AAPL, BTC-USD, AMD…"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                onFocus={() => suggestions.length > 0 && setSuggestionOpen(true)}
                autoFocus
              />
              {suggestionLoading && (
                <span className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              )}
            </div>
            {suggestionOpen && suggestions.length > 0 && (
              <ul className="absolute z-50 mt-1 w-full bg-card border border-card-border rounded-lg shadow-xl overflow-hidden">
                {suggestions.map((s) => (
                  <li key={s.symbol}>
                    <button
                      type="button"
                      onMouseDown={(e) => { e.preventDefault(); pickSuggestion(s); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-muted/60 transition-colors"
                    >
                      <span className="font-mono font-bold text-sm text-foreground w-20 shrink-0">{s.symbol}</span>
                      <span className="text-xs text-muted-foreground truncate flex-1">{s.name}</span>
                      <span className="text-xs text-muted-foreground/60 shrink-0">{TYPE_LABEL[s.type.toUpperCase()] ?? s.type}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Étiquette (optionnel)</label>
            <input
              className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="ex: Apple Inc."
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {alertType === "price" ? (
            <>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Condition</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setCondition("above")}
                    className={`py-2 text-sm font-medium rounded-md border transition-colors ${
                      condition === "above" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    ↑ Au-dessus
                  </button>
                  <button
                    onClick={() => setCondition("below")}
                    className={`py-2 text-sm font-medium rounded-md border transition-colors ${
                      condition === "below" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    ↓ En dessous
                  </button>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Prix cible</label>
                <input
                  type="number"
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring font-mono"
                  placeholder="0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </div>
            </>
          ) : alertType === "signal" ? (
            <>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Direction</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setPatternSignal("")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors ${
                      patternSignal === "" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    Les deux
                  </button>
                  <button
                    onClick={() => setPatternSignal("haussier")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors flex items-center justify-center gap-1 ${
                      patternSignal === "haussier" ? "bg-emerald-500 border-emerald-500 text-white" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    <TrendingUp className="w-3 h-3" /> Haussier
                  </button>
                  <button
                    onClick={() => setPatternSignal("baissier")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors flex items-center justify-center gap-1 ${
                      patternSignal === "baissier" ? "bg-red-500 border-red-500 text-white" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    <TrendingDown className="w-3 h-3" /> Baissier
                  </button>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Force minimale</label>
                <div className="grid grid-cols-2 gap-2">
                  {(["moyen", "fort"] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setMinStrength(s)}
                      className={`py-2 text-xs font-medium rounded-md border capitalize transition-colors ${
                        minStrength === s ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed bg-muted/50 rounded-md p-2">
                Tu seras notifié quand RSI, MACD, SMA et Bollinger s'alignent en signal composite (ACHAT/VENTE ou plus fort) —
                même analyse que dans l'onglet technique, vérifiée automatiquement toutes les 90 secondes.
              </p>
            </>
          ) : (
            <>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Type de signal</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setPatternSignal("")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors ${
                      patternSignal === "" ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    Les deux
                  </button>
                  <button
                    onClick={() => setPatternSignal("haussier")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors flex items-center justify-center gap-1 ${
                      patternSignal === "haussier" ? "bg-emerald-500 border-emerald-500 text-white" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    <TrendingUp className="w-3 h-3" /> Haussier
                  </button>
                  <button
                    onClick={() => setPatternSignal("baissier")}
                    className={`py-2 text-xs font-medium rounded-md border transition-colors flex items-center justify-center gap-1 ${
                      patternSignal === "baissier" ? "bg-red-500 border-red-500 text-white" : "bg-background border-input hover:bg-muted"
                    }`}
                  >
                    <TrendingDown className="w-3 h-3" /> Baissier
                  </button>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1 block">Force minimale du pattern</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["faible", "moyen", "fort"] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setMinStrength(s)}
                      className={`py-2 text-xs font-medium rounded-md border capitalize transition-colors ${
                        minStrength === s ? "bg-primary border-primary text-primary-foreground" : "bg-background border-input hover:bg-muted"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed bg-muted/50 rounded-md p-2">
                Tu seras notifié dès qu'un pattern de chandelier (marteau, avalement, étoile du matin/soir, etc.)
                correspondant apparaît sur ce titre — la même détection que dans l'analyse technique, gratuite, vérifiée
                automatiquement toutes les 90 secondes.
              </p>
            </>
          )}
        </div>

        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="flex-1 px-4 py-2 text-sm border border-border rounded-md hover:bg-muted transition-colors">
            Annuler
          </button>
          <button
            onClick={handleCreate}
            disabled={!canSubmit}
            className="flex-1 px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {create.isPending ? "Création..." : "Créer l'alerte"}
          </button>
        </div>
      </div>
    </div>
  );
}

const CHANNEL_META: Record<string, { label: string; Icon: typeof Mail }> = {
  push: { label: "Push", Icon: Smartphone },
  email: { label: "Email", Icon: Mail },
  sms: { label: "SMS", Icon: MessageSquare },
};

function formatSentAt(iso: string): string {
  const d = new Date(iso);
  const date = d.toLocaleDateString("fr-CA", { day: "numeric", month: "short", year: "numeric" });
  const time = d.toLocaleTimeString("fr-CA", { hour: "2-digit", minute: "2-digit" });
  return `${date} à ${time}`;
}

function NotificationHistoryRow({ n }: { n: NotificationEntry }) {
  const unread = !n.readAt;
  const TypeIcon = n.alertType === "pattern" ? Sparkles : n.alertType === "signal" ? TrendingUp : Bell;
  return (
    <div className={`flex items-start gap-3 px-4 py-3 ${unread ? "bg-primary/5" : ""}`}>
      <span className="relative shrink-0 mt-0.5">
        <TypeIcon className={`w-4 h-4 ${unread ? "text-primary" : "text-muted-foreground"}`} />
        {unread && <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-primary" />}
      </span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-sm ${unread ? "font-semibold" : "font-medium"}`}>{n.title}</span>
          {unread && (
            <span className="text-[10px] uppercase tracking-wide bg-primary/10 text-primary px-1.5 py-0.5 rounded font-semibold">
              Non lu
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">{n.body}</p>
        <div className="flex items-center gap-2 mt-1 text-[11px] text-muted-foreground/70">
          <time dateTime={n.sentAt} className="font-mono">{formatSentAt(n.sentAt)}</time>
          <span aria-hidden>·</span>
          <span className="flex items-center gap-1.5">
            {n.channels.map((c) => {
              const meta = CHANNEL_META[c];
              if (!meta) return null;
              const { Icon, label } = meta;
              return (
                <span key={c} className="flex items-center gap-0.5" title={`Envoyé par ${label}`}>
                  <Icon className="w-3 h-3" /> {label}
                </span>
              );
            })}
          </span>
        </div>
      </div>
    </div>
  );
}

/**
 * Centre de notifications — historique chronologique de toutes les
 * notifications envoyées (heure exacte + canaux). Le passage sur cette
 * section marque tout comme lu après un court délai, ce qui éteint le badge
 * « non lu » de la sidebar.
 */
function NotificationHistory() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: notifications = [], isLoading } = useGetNotifications({ query: { refetchInterval: 30_000 } as any });
  const queryClient = useQueryClient();
  const markAllRead = useMarkAllNotificationsRead({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetNotificationsUnreadCountQueryKey() });
      },
    },
  });

  const unreadCount = notifications.filter((n) => !n.readAt).length;
  const hasUnread = unreadCount > 0;
  const markPending = markAllRead.isPending;
  const mutateRef = useRef(markAllRead.mutate);
  mutateRef.current = markAllRead.mutate;

  // Consultation = lu : après 2,5 s passées avec l'historique à l'écran, on
  // marque tout comme lu (le temps que l'utilisateur voie les badges « non lu »).
  useEffect(() => {
    if (!hasUnread || markPending) return;
    const t = setTimeout(() => mutateRef.current(), 2_500);
    return () => clearTimeout(t);
  }, [hasUnread, markPending]);

  if (isLoading || notifications.length === 0) return null;

  return (
    <div className="mt-5">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
          <History className="w-3.5 h-3.5" />
          Historique des notifications
          {hasUnread && (
            <span className="normal-case tracking-normal text-[10px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-bold">
              {unreadCount} non lu{unreadCount > 1 ? "s" : ""}
            </span>
          )}
        </h2>
        {hasUnread && (
          <button
            onClick={() => markAllRead.mutate()}
            disabled={markPending}
            className="text-xs text-primary hover:underline disabled:opacity-50"
          >
            Tout marquer comme lu
          </button>
        )}
      </div>
      <div className="bg-card border border-card-border rounded-lg divide-y divide-border max-h-96 overflow-y-auto">
        {notifications.map((n) => (
          <NotificationHistoryRow key={n.id} n={n} />
        ))}
      </div>
      <p className="text-[11px] text-muted-foreground/60 mt-1.5">
        Chaque notification envoyée (push, email, SMS) est archivée ici avec son heure exacte — même si l'alerte d'origine a été supprimée.
      </p>
    </div>
  );
}

function AlertRow({ alert, onDelete, muted = false }: { alert: Alert; onDelete: () => void; muted?: boolean }) {
  const isPattern = alert.alertType === "pattern";
  const isSignal = alert.alertType === "signal";
  return (
    <div className={`flex items-center gap-4 px-4 py-3 group hover:bg-muted/30 transition-colors ${muted ? "opacity-60" : ""}`}>
      {muted ? (
        <BellOff className="w-4 h-4 shrink-0 text-muted-foreground" />
      ) : isPattern ? (
        <Sparkles className="w-4 h-4 text-primary shrink-0" />
      ) : isSignal ? (
        <TrendingUp className="w-4 h-4 text-primary shrink-0" />
      ) : (
        <Bell className="w-4 h-4 text-primary shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-mono font-bold text-sm">{alert.symbol}</span>
          {alert.name && <span className="text-xs text-muted-foreground truncate">{alert.name}</span>}
          {isSignal && !muted && <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded font-medium">📈 signal technique</span>}
          {muted && <span className="text-xs bg-muted px-1.5 py-0.5 rounded font-medium">Déclenchée</span>}
        </div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {isPattern ? (
            <>
              Alerte pattern —{" "}
              <span className={
                alert.patternSignal === "haussier" ? "gain font-medium" :
                alert.patternSignal === "baissier" ? "loss font-medium" : "font-medium"
              }>
                {alert.patternSignal === "haussier" ? "signal haussier" : alert.patternSignal === "baissier" ? "signal baissier" : "haussier ou baissier"}
              </span>{" "}
              · force min. {alert.minStrength ?? "faible"}
            </>
          ) : isSignal ? (
            <>
              Signal composite RSI+MACD+SMA+Bollinger —{" "}
              <span className={
                alert.patternSignal === "haussier" ? "gain font-medium" :
                alert.patternSignal === "baissier" ? "loss font-medium" : "font-medium"
              }>
                {alert.patternSignal === "haussier" ? "haussier seulement" : alert.patternSignal === "baissier" ? "baissier seulement" : "tous signaux"}
              </span>{" "}
              · force min. {alert.minStrength ?? "moyen"}
            </>
          ) : (
            <>
              Alerte si le prix passe{" "}
              <span className={alert.condition === "above" ? "gain font-medium" : "loss font-medium"}>
                {alert.condition === "above" ? "au-dessus" : "en dessous"}
              </span>{" "}
              de <span className="font-mono font-medium text-foreground">{alert.targetPrice !== null && alert.targetPrice !== undefined ? formatPrice(alert.targetPrice) : "—"}</span>
            </>
          )}
          {muted && alert.triggeredAt && ` — ${new Date(alert.triggeredAt).toLocaleDateString("fr-CA")}`}
        </div>
      </div>
      <button
        onClick={onDelete}
        className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-all"
      >
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

export default function Alerts() {
  const [showCreate, setShowCreate] = useState(false);
  const [notifPerm, setNotifPerm] = useState<NotificationPermission>("default");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: alerts = [], isLoading } = useGetAlerts({ query: { refetchInterval: 30_000 } as any });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const del = useDeleteAlert({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAlertsQueryKey() });
        playSound("click");
        toast({ title: "Alerte supprimée" });
      },
    },
  });

  useEffect(() => {
    if ("Notification" in window) {
      setNotifPerm(Notification.permission);
    }
  }, []);

  const active = alerts.filter((a: Alert) => a.active);
  const triggered = alerts.filter((a: Alert) => !a.active && a.triggeredAt);

  return (
    <div className="p-6 max-w-3xl">
      {showCreate && <CreateAlertModal onClose={() => setShowCreate(false)} />}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold">Alertes</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{active.length} alerte{active.length !== 1 ? "s" : ""} active{active.length !== 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => { playSound("click"); setShowCreate(true); }}
          className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" />
          Nouvelle alerte
        </button>
      </div>

      {notifPerm !== "granted" && (
        <div className="mb-5 flex items-center gap-3 bg-accent border border-accent-border rounded-lg px-4 py-3">
          <Bell className="w-4 h-4 text-accent-foreground shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-accent-foreground">Activer les notifications du navigateur</p>
            <p className="text-xs text-muted-foreground">Recevez une notification dès qu'une alerte se déclenche.</p>
          </div>
          <button
            onClick={async () => {
              requestNotificationPermission();
              const perm = await Notification.requestPermission();
              setNotifPerm(perm);
              if (perm === "granted") {
                sendNotification("Notifications activées ✅", "Vous recevrez des alertes, même si l'onglet est fermé.");
                // Informe le service worker : vérification immédiate + polling 60 s
                if ("serviceWorker" in navigator) {
                  navigator.serviceWorker.ready.then((reg) => {
                    reg.active?.postMessage({ type: "start-alert-polling" });
                    reg.active?.postMessage({ type: "check-alerts-now" });
                  }).catch(() => {});
                }
                // Abonne ce navigateur au Web Push (notifications même
                // navigateur complètement fermé) — géré dans main.tsx.
                window.dispatchEvent(new Event("soliris:notifications-granted"));
              }
            }}
            className="shrink-0 px-3 py-1.5 text-xs font-medium bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity"
          >
            Activer
          </button>
        </div>
      )}

      {isLoading ? (
        <div className="bg-card border border-card-border rounded-lg divide-y divide-border">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="px-4 py-4 flex justify-between animate-pulse">
              <div><div className="h-4 bg-muted rounded w-20 mb-2" /><div className="h-3 bg-muted rounded w-40" /></div>
              <div className="h-4 bg-muted rounded w-16" />
            </div>
          ))}
        </div>
      ) : alerts.length === 0 ? (
        <div className="bg-card border border-card-border rounded-xl p-12 text-center">
          <Bell className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
          <p className="font-semibold text-foreground mb-1">Aucune alerte configurée</p>
          <p className="text-sm text-muted-foreground mb-4">Créez une alerte de prix, ou une alerte intelligente basée sur les patterns de chandeliers.</p>
          <button
            onClick={() => { playSound("click"); setShowCreate(true); }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            Créer votre première alerte
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {active.length > 0 && (
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Actives</h2>
              <div className="bg-card border border-card-border rounded-lg divide-y divide-border">
                {active.map((alert: Alert) => (
                  <AlertRow key={alert.id} alert={alert} onDelete={() => del.mutate({ id: alert.id })} />
                ))}
              </div>
            </div>
          )}

          {triggered.length > 0 && (
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Déclenchées</h2>
              <div className="bg-card border border-card-border rounded-lg divide-y divide-border">
                {triggered.map((alert: Alert) => (
                  <AlertRow key={alert.id} alert={alert} onDelete={() => del.mutate({ id: alert.id })} muted />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <NotificationHistory />
    </div>
  );
}
