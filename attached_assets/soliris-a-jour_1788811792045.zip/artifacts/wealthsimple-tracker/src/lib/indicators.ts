/**
 * Indicateurs techniques — ré-export du paquet partagé.
 *
 * L'implémentation vit désormais dans `@workspace/indicators`, importée aussi
 * bien par le frontend (graphiques) que par l'API (alertes, auto-trader), afin
 * que le score affiché et le score qui décide proviennent du même code.
 *
 * Ce fichier ne subsiste que pour ne pas toucher aux imports `@/lib/indicators`
 * existants ; il n'a plus de logique propre.
 */
export * from "@workspace/indicators";
