#!/usr/bin/env node
/**
 * Audit visuel — parcourt toutes les pages et signale ce qui se voit mal.
 * ─────────────────────────────────────────────────────────────────────────────
 * Écrit après avoir découvert, en regardant simplement l'application tourner,
 * que TOUTES ses pages mesuraient 5764 px de large pour une fenêtre de 1440 :
 * un enfant flex sans min-w-0 se dimensionnait sur le bandeau de cotations au
 * lieu de le rogner. Personne ne l'avait vu — on ne pense pas à faire défiler
 * vers la droite. Ce script le voit en quelques secondes.
 *
 * Ce qu'il détecte, page par page :
 *   • débordement horizontal (scrollWidth > clientWidth)
 *   • page plantée (le garde-fou d'erreur a pris la main)
 *   • blocs restés invisibles (une révélation au défilement qui ne part pas)
 *   • erreurs de console et exceptions non rattrapées
 *
 * Ce qu'il ne fait PAS : juger si c'est joli. Il attrape les défauts
 * mesurables, pas les questions de goût.
 *
 * ── Utilisation ──────────────────────────────────────────────────────────────
 *   npm i -D playwright && npx playwright install chromium     (une seule fois)
 *   pnpm dev                                                    (dans un terminal)
 *   node scripts/audit-visuel.mjs                               (dans un autre)
 *
 * Variables d'environnement :
 *   AUDIT_URL       adresse de l'app          (défaut http://localhost:5173)
 *   AUDIT_PASSWORD  mot de passe de connexion (sinon seules les pages
 *                   publiques sont auditées)
 *   AUDIT_OUT       dossier des captures      (défaut ./captures-audit)
 *
 * Code de sortie 1 si au moins un problème est trouvé — utilisable en CI.
 */
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";

const BASE = process.env.AUDIT_URL ?? "http://localhost:5173";
const PASSWORD = process.env.AUDIT_PASSWORD ?? "";
const OUT = process.env.AUDIT_OUT ?? "./captures-audit";

const PUBLIC_ROUTES = ["/", "/tarifs", "/login", "/conditions-utilisation"];
const PRIVATE_ROUTES = [
  "/dashboard", "/search", "/watchlist", "/alerts", "/journal", "/performance",
  "/comparer", "/correlation", "/calendrier", "/ordres", "/debrief",
  "/reconciliation", "/audit", "/agent-tasks", "/auto-trader", "/parametres",
  "/copy-trading", "/copy-trading/decouvrir", "/apprendre", "/courtier",
  "/quote/AAPL",
];

/** Bruit réseau attendu quand une intégration externe n'est pas configurée. */
const BRUIT_ATTENDU = /ERR_TUNNEL|ERR_FAILED|ERR_CONNECTION|Failed to load resource|favicon/i;

mkdirSync(OUT, { recursive: true });

// AUDIT_BROWSER : chemin d'un Chromium déjà installé, pour les environnements
// où « npx playwright install » n'est pas possible. Sinon Playwright utilise
// celui qu'il a téléchargé.
const navigateur = await chromium.launch(
  process.env.AUDIT_BROWSER ? { executablePath: process.env.AUDIT_BROWSER } : {},
);
const contexte = await navigateur.newContext({
  viewport: { width: 1440, height: 1000 },
  colorScheme: "dark",
  deviceScaleFactor: 2,
});

// ─── Connexion, si un mot de passe est fourni ────────────────────────────────
let routes = PUBLIC_ROUTES;
if (PASSWORD) {
  const page = await contexte.newPage();
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.fill('input[type="password"]', PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForTimeout(2500);
  const connecte = !page.url().includes("/login");
  console.log(connecte ? "Connecté.\n" : "Connexion refusée — pages publiques seulement.\n");
  if (connecte) routes = [...PUBLIC_ROUTES, ...PRIVATE_ROUTES];
  await page.close();
} else {
  console.log("Sans AUDIT_PASSWORD : pages publiques seulement.\n");
}

let enDefaut = 0;

for (const route of routes) {
  const page = await contexte.newPage();
  const erreurs = [];
  page.on("pageerror", (e) => erreurs.push(`exception : ${e.message.slice(0, 120)}`));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    const t = m.text();
    if (!BRUIT_ATTENDU.test(t)) erreurs.push(`console : ${t.slice(0, 140)}`);
  });

  try {
    await page.goto(BASE + route, { waitUntil: "networkidle", timeout: 30_000 });
  } catch {
    console.log(`⚠  ${route.padEnd(28)} inaccessible`);
    enDefaut++;
    await page.close();
    continue;
  }

  // Faire défiler : c'est ce qui déclenche les révélations au scroll, et donc
  // ce qui révèle celles qui ne partent pas.
  for (let i = 0; i < 6; i++) {
    await page.mouse.wheel(0, 700);
    await page.waitForTimeout(250);
  }
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(900);

  const diag = await page.evaluate(() => {
    const racine = document.documentElement;
    const plantee = document.body.innerText.includes("Erreur sur la page");
    const invisibles = [...document.querySelectorAll("main *, body > div *")]
      .filter((el) => {
        const s = getComputedStyle(el);
        return (
          parseFloat(s.opacity) < 0.05 &&
          el.textContent.trim().length > 25 &&
          el.getBoundingClientRect().height > 0
        );
      })
      .slice(0, 3)
      .map((el) => el.textContent.trim().slice(0, 40));
    // Le coupable d'un débordement est le premier élément qui dépasse.
    const coupable = [...document.querySelectorAll("body *")]
      .find((el) => el.getBoundingClientRect().right > window.innerWidth + 40);
    return {
      debordement: racine.scrollWidth - racine.clientWidth,
      coupable: coupable ? `${coupable.tagName}.${String(coupable.className).slice(0, 50)}` : null,
      plantee,
      invisibles,
    };
  });

  const problemes = [];
  if (diag.plantee) problemes.push("PAGE PLANTÉE");
  if (diag.debordement > 8) {
    problemes.push(`déborde de ${diag.debordement} px${diag.coupable ? ` (${diag.coupable})` : ""}`);
  }
  if (diag.invisibles.length) {
    problemes.push(`invisible : « ${diag.invisibles[0]}… »`);
  }
  problemes.push(...erreurs.slice(0, 2));

  const nom = route.replace(/\//g, "_") || "_accueil";
  if (problemes.length) {
    enDefaut++;
    await page.screenshot({ path: `${OUT}/${nom}.png`, fullPage: false });
    console.log(`⚠  ${route.padEnd(28)} ${problemes.join(" · ")}`);
  } else {
    console.log(`   ${route.padEnd(28)} ok`);
  }

  await page.close();
}

await navigateur.close();

console.log(
  enDefaut === 0
    ? `\n${routes.length} pages, aucun problème.`
    : `\n${enDefaut} page(s) en défaut sur ${routes.length}. Captures dans ${OUT}/`,
);
process.exit(enDefaut === 0 ? 0 : 1);
